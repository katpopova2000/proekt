#pragma once

#include "../objects/Report.h"

#include "creator_global.h"

class CREATOR_EXPORT ReportCreator
{
public:
  ReportCreator();

  Report CreateReport(const QString& text) const;
};
