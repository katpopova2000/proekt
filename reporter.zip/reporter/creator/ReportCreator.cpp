#include "ReportCreator.h"

#include <QDateTime>

ReportCreator::ReportCreator()
{
}

Report ReportCreator::CreateReport(const QString& text) const
{
  QString reportText = text + "\n" + QDateTime::currentDateTime().toString();
  Report report;
  report.SetText(reportText);
  return report;
}
