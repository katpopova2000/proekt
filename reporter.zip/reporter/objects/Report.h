#pragma once

#include <QString>

#include "objects_global.h"

class OBJECTS_EXPORT Report
{
public:
  Report();

  void SetText(const QString& text);
  const QString& GetText() const;

private:
  QString m_text;
};
