#include "Report.h"

Report::Report()
{
}

void Report::SetText(const QString& text)
{
  m_text = text;
}

const QString& Report::GetText() const
{
  return m_text;
}
