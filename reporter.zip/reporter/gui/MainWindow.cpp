#include "MainWindow.h"
#include "ui_MainWindow.h"

#include "../creator/ReportCreator.h"

MainWindow::MainWindow(QWidget *parent)
  : QMainWindow(parent)
  , ui(new Ui::MainWindow)
{
  ui->setupUi(this);
}

MainWindow::~MainWindow()
{
  delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    ReportCreator reportCreator;
    Report report = reportCreator.CreateReport(ui->lineEdit->text());
    ui->textEdit->setText(report.GetText());
}
